# AKASH WORLD
**Play • Talk • Connect • Enjoy**

Premium social voice rooms and gaming starter built with React, TypeScript, Supabase and LiveKit.

## Included in this project
- Responsive dark black / royal purple / metallic gold UI.
- Discover dashboard, categories, room search, room cards and create-room flow.
- Supabase Auth email/password sign-up, sign-in and password reset.
- Profile, wallet, VIP, gifts, leaderboard, settings and admin route foundations.
- Room creation, unique Room IDs, participant records and real-time room/chat subscriptions.
- LiveKit WebRTC connection flow with server-side token minting Edge Function.
- Tic Tac Toe game logic; game lobby cards for Ludo, Carrom, Snake, Quiz and Spin Wheel.
- PostgreSQL schema, indexes, trigger, seed gift/game rows and Row Level Security policies.

> This is a runnable full-stack starter, not a claim that every requested production feature is already complete. Real voice requires LiveKit credentials; cloud features require a Supabase project. Multiplayer Ludo/Carrom/Quiz, DMs, voice notes, payment processing, gift ledger, advanced moderation and complete admin analytics need their server-side workflows and game-specific implementations before public launch.

## 1. Requirements
- Node.js 20+
- A Supabase project
- A LiveKit Cloud project (or self-hosted LiveKit server)

## 2. Run locally
```bash
npm install
cp .env.example .env
# Edit .env with your Supabase project URL and anon key and LiveKit websocket URL.
npm run dev
```
Open the Vite URL shown in the terminal.

## 3. Configure Supabase
1. Open Supabase Dashboard → SQL Editor.
2. Run `supabase/migrations/001_initial_schema.sql`.
3. In Project Settings → API, copy Project URL and anon/public key into `.env`.
4. Enable Email provider under Authentication → Providers.
5. In Authentication → URL Configuration, add your local and deployed redirect URLs.
6. Ensure `rooms`, `room_participants`, and `messages` are included in the `supabase_realtime` publication (the migration attempts to add them).

### Create an administrator
After signing up, promote the intended account manually from the Supabase SQL Editor:
```sql
update public.profiles
set is_admin = true
where id = 'YOUR_AUTH_USER_UUID';
```
Never expose admin service-role credentials in the browser. The starter profile update policy prevents a user from changing their own admin flag.

## 4. Configure LiveKit voice
Deploy the Edge Function:
```bash
supabase functions deploy livekit-token
```
Set secrets (use your actual values):
```bash
supabase secrets set LIVEKIT_API_KEY=your_key LIVEKIT_API_SECRET=your_secret LIVEKIT_URL=wss://your-project.livekit.cloud
```
`LIVEKIT_API_KEY` and `LIVEKIT_API_SECRET` are server-side secrets only. Do not add them to `.env` with a `VITE_` prefix. The function validates the caller's Supabase access token and mints a room-scoped one-hour token.

The frontend currently uses the room UUID as the LiveKit room identifier. For production, add a server-side check that the user is allowed into a private room before minting the token, enforce room capacity and role grants, and close LiveKit rooms when the app room ends.

## 5. Storage
Create a public `avatars` bucket and a `room-covers` bucket only if public images are intended. For private uploads, use private buckets and signed URLs. Add object policies so users can upload only to their own user-id folder.

## 6. Production hardening checklist
- Add rate limits and CAPTCHA to signup, room creation, messages and report submission.
- Add server-side authorization for moderator actions, private room passwords, seat assignment, room capacity and invitation flows.
- Add a private-room password verification Edge Function; never store plaintext passwords.
- Add DM conversation membership tables and RLS before enabling private messaging.
- Use an atomic server-side ledger function for gifts and coin/diamond changes. Never let clients update balances or write completed transactions.
- Integrate a payment provider only through verified webhooks; do not trust client purchase callbacks.
- Add server-authoritative game sessions and move multiplayer game state transitions to Edge Functions or a dedicated game server.
- Add report review queues, audit logs, block-aware discovery/chat policies, moderation tooling and retention policies.
- Add tests, error monitoring, backups, analytics, CSP/security headers and deployment environment separation.
- Review RLS policies with test users before launch. Do not disable RLS to make the UI work.

## 7. Deploy
Build with `npm run build` and deploy the `dist/` directory to Vercel, Netlify or another static hosting provider. Configure the same `VITE_` environment variables in the hosting dashboard. Deploy the Supabase Edge Function separately.

## Project structure
```text
src/
  App.tsx
  main.tsx
  styles.css
  lib/
    api.ts
    gameLogic.ts
    livekit.ts
    supabase.ts
    types.ts
supabase/
  migrations/001_initial_schema.sql
  functions/livekit-token/index.ts
```

## Important
The browser uses only the Supabase anon key. Keep Supabase service-role keys, LiveKit API secret and payment-provider secrets on trusted servers. The demo room cards shown when Supabase is not configured are sample preview data, not live users.
