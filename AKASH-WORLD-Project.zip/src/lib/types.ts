export type RoomCategory = 'Music' | 'Chat' | 'Gaming' | 'Friendship' | 'Entertainment'
export type Room = {
  id: string; room_code: string; name: string; description: string | null
  category: RoomCategory; cover_url: string | null; is_private: boolean
  has_password: boolean; seat_count: number; participant_count?: number
  host_id: string; created_at: string
}
export type Profile = {
  id: string; username: string; display_name: string | null
  avatar_url: string | null; level: number; xp: number; coins: number
  diamonds: number; vip_tier: string; is_admin: boolean
}
