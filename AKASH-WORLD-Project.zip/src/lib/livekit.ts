import { supabase } from './supabase'

export async function fetchLiveKitToken(roomName: string, identity: string) {
  // Token is minted server-side. The API secret must never reach the browser.
  const { data, error } = await supabase.functions.invoke('livekit-token', {
    body: { roomName, identity }
  })
  if (error) throw error
  if (!data?.token || !data?.url) throw new Error('Voice service is not configured. Set LiveKit secrets and URL.')
  return data as { token: string; url: string }
}
