import { supabase } from './supabase'
import type { Room, Profile } from './types'

export async function getRooms(): Promise<Room[]> {
  const { data, error } = await supabase.from('rooms')
    .select('*, room_participants(count)').eq('status', 'live')
    .order('created_at', { ascending: false }).limit(30)
  if (error) throw error
  return (data || []).map((r: any) => ({ ...r, participant_count: r.room_participants?.[0]?.count || 0 }))
}
export async function getProfile(userId: string): Promise<Profile | null> {
  const { data, error } = await supabase.from('profiles').select('*').eq('id', userId).maybeSingle()
  if (error) throw error
  return data
}
export async function createRoom(input: {
  name: string; category: string; seat_count: number; is_private: boolean; description?: string
}, userId: string) {
  const code = String(Math.floor(100000 + Math.random() * 900000))
  const { data, error } = await supabase.from('rooms').insert({
    ...input, room_code: code, host_id: userId, status: 'live'
  }).select().single()
  if (error) throw error
  const { error: joinError } = await supabase.from('room_participants').insert({
    room_id: data.id, user_id: userId, role: 'host'
  })
  if (joinError) throw joinError
  return data as Room
}
export async function joinRoom(roomId: string, userId: string) {
  const { error } = await supabase.from('room_participants').upsert(
    { room_id: roomId, user_id: userId, role: 'listener' }, { onConflict: 'room_id,user_id' }
  )
  if (error) throw error
}
export async function leaveRoom(roomId: string, userId: string) {
  const { error } = await supabase.from('room_participants').delete().eq('room_id', roomId).eq('user_id', userId)
  if (error) throw error
}
