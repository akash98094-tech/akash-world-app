import { useEffect, useMemo, useState } from 'react'
import { Link, NavLink, Route, Routes, useNavigate, useParams } from 'react-router-dom'
import {
  Activity, ArrowDownLeft, ArrowUpRight, Bell, Crown, Gamepad2, Gift, Headphones,
  Home, LogIn, LogOut, Menu, MessageCircle, Mic2, Plus, Search, Settings, Shield,
  Sparkles, Star, Users, Wallet, X, Zap, ChevronRight, LockKeyhole, Radio, Trophy
} from 'lucide-react'
import { LiveKitRoom, RoomAudioRenderer, GridLayout, ParticipantTile, useTracks } from '@livekit/components-react'
import { Track } from 'livekit-client'
import '@livekit/components-styles'
import { supabase, isSupabaseConfigured } from './lib/supabase'
import { createRoom, getRooms, joinRoom, leaveRoom, getProfile } from './lib/api'
import { fetchLiveKitToken } from './lib/livekit'
import { getWinner, type Mark } from './lib/gameLogic'
import type { Room, Profile } from './lib/types'

const demoRooms: Room[] = [
  {id:'demo-1',room_code:'117125',name:'Midnight Music Lounge',description:'Late night music and good vibes',category:'Music',cover_url:null,is_private:false,has_password:false,seat_count:16,participant_count:128,host_id:'demo',created_at:new Date().toISOString()},
  {id:'demo-2',room_code:'482901',name:'Friends Forever ✨',description:'Meet new people and have a chat',category:'Friendship',cover_url:null,is_private:false,has_password:false,seat_count:12,participant_count:76,host_id:'demo',created_at:new Date().toISOString()},
  {id:'demo-3',room_code:'930144',name:'Gaming Arena',description:'Games, challenges and fun',category:'Gaming',cover_url:null,is_private:false,has_password:false,seat_count:16,participant_count:54,host_id:'demo',created_at:new Date().toISOString()},
]
const categories = ['All','Music','Chat','Gaming','Friendship','Entertainment'] as const
type Category = typeof categories[number]
const money = (n:number) => n.toLocaleString()

export default function App() {
  const [session, setSession] = useState<any>(null)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [rooms, setRooms] = useState<Room[]>(demoRooms)
  const [loading, setLoading] = useState(true)
  const [notice, setNotice] = useState('')
  const [showCreate, setShowCreate] = useState(false)
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState<Category>('All')
  const [mobileMenu, setMobileMenu] = useState(false)
  const [guest, setGuest] = useState(false)
  const navigate = useNavigate()

  async function refreshRooms() {
    if (!isSupabaseConfigured) { setRooms(demoRooms); return }
    try { setRooms(await getRooms()) } catch (e:any) { setNotice(e.message || 'Could not load rooms') }
  }
  useEffect(() => {
    let mounted = true
    supabase.auth.getSession().then(async ({data}) => {
      if (!mounted) return
      setSession(data.session)
      if (data.session?.user) {
        try { setProfile(await getProfile(data.session.user.id)) } catch {}
      }
      await refreshRooms()
      setLoading(false)
    })
    const { data: listener } = supabase.auth.onAuthStateChange(async (_event, next) => {
      setSession(next)
      if (next?.user) { try { setProfile(await getProfile(next.user.id)) } catch {} }
      else setProfile(null)
    })
    return () => { mounted = false; listener.subscription.unsubscribe() }
  }, [])
  useEffect(() => {
    if (!isSupabaseConfigured) return
    const channel = supabase.channel('live-rooms')
      .on('postgres_changes', {event:'*',schema:'public',table:'rooms'}, () => refreshRooms())
      .on('postgres_changes', {event:'*',schema:'public',table:'room_participants'}, () => refreshRooms())
      .subscribe()
    return () => { supabase.removeChannel(channel) }
  }, [])
  const filtered = useMemo(() => rooms.filter(r =>
    (category === 'All' || r.category === category) &&
    (r.name.toLowerCase().includes(search.toLowerCase()) || r.room_code.includes(search))
  ), [rooms, category, search])
  const user = session?.user
  const displayName = profile?.display_name || profile?.username || user?.email?.split('@')[0] || 'Guest Explorer'

  async function signOut() { await supabase.auth.signOut(); setGuest(false); navigate('/') }
  async function handleCreate(input:any) {
    if (!user) { setNotice('Please sign in to create a room.'); navigate('/auth'); return }
    try {
      const room = await createRoom(input, user.id); setShowCreate(false); await refreshRooms(); navigate(`/room/${room.id}`)
    } catch (e:any) { setNotice(e.message || 'Room creation failed') }
  }

  return <div className="app-shell">
    <div className="ambient ambient-one"/><div className="ambient ambient-two"/>
    <header className="topbar">
      <Link to="/" className="brand"><span className="brand-mark">A</span><span>AKASH<span className="gold"> WORLD</span><small>PLAY • TALK • CONNECT • ENJOY</small></span></Link>
      <div className="top-search"><Search size={17}/><input placeholder="Search rooms, people or Room ID..." value={search} onChange={e=>setSearch(e.target.value)}/><kbd>⌘ K</kbd></div>
      <div className="top-actions">
        <button className="icon-btn" aria-label="Notifications" onClick={()=>setNotice('You are all caught up!')}><Bell size={19}/><i/></button>
        <div className="coin-pill"><span>◆</span> {money(profile?.coins ?? 2500)}</div>
        {user ? <button className="profile-chip" onClick={()=>navigate('/profile')}><span className="avatar">{displayName.slice(0,1).toUpperCase()}</span><span>{displayName}</span></button> : <Link className="btn btn-gold btn-small" to="/auth"><LogIn size={15}/> Sign in</Link>}
        <button className="icon-btn mobile-toggle" onClick={()=>setMobileMenu(!mobileMenu)}><Menu/></button>
      </div>
    </header>
    <div className="layout">
      <aside className={`sidebar ${mobileMenu?'sidebar-open':''}`}>
        <div className="sidebar-label">MENU</div>
        <NavItem to="/" icon={<Home/>} label="Discover"/>
        <NavItem to="/games" icon={<Gamepad2/>} label="Game Center"/>
        <NavItem to="/messages" icon={<MessageCircle/>} label="Messages"/>
        <NavItem to="/gifts" icon={<Gift/>} label="Gift Gallery"/>
        <NavItem to="/leaderboard" icon={<Trophy/>} label="Leaderboard"/>
        <div className="sidebar-label spaced">YOUR SPACE</div>
        <NavItem to="/profile" icon={<Users/>} label="My Profile"/>
        <NavItem to="/wallet" icon={<Wallet/>} label="My Wallet"/>
        <NavItem to="/settings" icon={<Settings/>} label="Settings"/>
        <div className="sidebar-bottom">
          <div className="vip-card"><Crown size={20}/><b>Unlock VIP</b><p>Stand out with exclusive frames and perks.</p><Link to="/vip">Explore VIP <ChevronRight size={14}/></Link></div>
          <div className="sidebar-user"><span className="avatar">{displayName.slice(0,1).toUpperCase()}</span><div><b>{displayName}</b><small>{user?'Member':'Guest mode'}</small></div>{user?<button className="plain-icon" onClick={signOut}><LogOut size={16}/></button>:<Link to="/auth"><LogIn size={16}/></Link>}</div>
        </div>
      </aside>
      <main className="main-content">
        {notice && <div className="toast" role="status">{notice}<button onClick={()=>setNotice('')}><X size={15}/></button></div>}
        {loading ? <Loading/> : <Routes>
          <Route path="/" element={<HomePage rooms={filtered} allRooms={rooms} category={category} setCategory={setCategory} search={search} setSearch={setSearch} onCreate={()=>setShowCreate(true)} onJoin={id=>navigate(`/room/${id}`)} displayName={displayName}/>}/>
          <Route path="/auth" element={<AuthPage onDone={()=>navigate('/')}/>}/>
          <Route path="/room/:id" element={<RoomPage user={user} profile={profile} rooms={rooms} onNotice={setNotice}/>}/>
          <Route path="/games" element={<GamesPage/>}/>
          <Route path="/messages" element={<MessagesPage user={user}/>}/>
          <Route path="/gifts" element={<GiftsPage user={user} onNotice={setNotice}/>}/>
          <Route path="/leaderboard" element={<LeaderboardPage/>}/>
          <Route path="/profile" element={<ProfilePage profile={profile} user={user} displayName={displayName}/>}/>
          <Route path="/wallet" element={<WalletPage profile={profile}/>}/>
          <Route path="/vip" element={<VipPage/>}/>
          <Route path="/settings" element={<SettingsPage/>}/>
          <Route path="/admin" element={<AdminPage profile={profile}/>}/>
          <Route path="*" element={<div className="empty-state"><h2>Page not found</h2><Link to="/">Return home</Link></div>}/>
        </Routes>}
        <footer>© 2026 AKASH WORLD <span>Made for moments that matter.</span><span>Privacy · Community Guidelines · Help</span></footer>
      </main>
    </div>
    <nav className="mobile-nav">
      <MobileNav to="/" icon={<Home/>} label="Home"/><MobileNav to="/games" icon={<Gamepad2/>} label="Games"/>
      <button onClick={()=>setShowCreate(true)} className="mobile-create"><Plus/></button>
      <MobileNav to="/messages" icon={<MessageCircle/>} label="Chat"/><MobileNav to="/profile" icon={<Users/>} label="Profile"/>
    </nav>
    {showCreate && <CreateRoomModal onClose={()=>setShowCreate(false)} onCreate={handleCreate}/>}
  </div>
}

function NavItem({to,icon,label}:any){return <NavLink to={to} end={to==='/'} className={({isActive})=>`nav-item ${isActive?'active':''}`}>{icon}<span>{label}</span>{label==='Messages'&&<i className="nav-dot"/>}</NavLink>}
function MobileNav({to,icon,label}:any){return <NavLink to={to} end={to==='/'} className={({isActive})=>`mobile-nav-item ${isActive?'active':''}`}>{icon}<small>{label}</small></NavLink>}
function Loading(){return <div className="loading-screen"><div className="loader-logo">A</div><h2>AKASH <span className="gold">WORLD</span></h2><div className="loading-line"/></div>}

function HomePage({rooms,allRooms,category,setCategory,onCreate,onJoin,displayName}:any){
  return <div className="page">
    <section className="hero">
      <div className="hero-copy"><div className="eyebrow"><Sparkles size={14}/> YOUR WORLD. YOUR PEOPLE.</div><h1>Every moment<br/>has a <span className="gradient-text">connection.</span></h1><p>Find your people, join the conversation, and make every moment count.</p><div className="hero-actions"><button className="btn btn-gold" onClick={onCreate}><Plus size={17}/> Create a room</button><a href="#rooms" className="btn btn-glass"><Radio size={17}/> Explore live rooms</a></div><div className="hero-stats"><div><b>{allRooms.reduce((a:any,r:any)=>a+(r.participant_count||0),0)+258}</b><small>People online</small></div><div><b>{allRooms.length+12}</b><small>Live rooms</small></div><div><b>4.9 <span className="gold">★</span></b><small>Community rating</small></div></div></div>
      <div className="hero-art"><div className="orbit orbit-a"/><div className="orbit orbit-b"/><div className="hero-orb"><div className="orb-core">A<span>W</span></div><div className="orb-ring">✦</div></div><div className="float-tag tag-live"><i/> LIVE NOW <b>128</b></div><div className="float-tag tag-vip"><Crown size={15}/> VIP LOUNGE</div><div className="float-tag tag-mic"><Mic2 size={16}/> 16 MIC SEATS</div></div>
    </section>
    <div className="welcome-row"><div><h2>Welcome back, {displayName} <span>✦</span></h2><p>Your next great conversation is one tap away.</p></div><div className="online-friends"><div className="avatar-stack"><span>R</span><span>M</span><span>A</span><span>+</span></div><small><b>24 friends</b> online</small></div></div>
    <section id="rooms" className="section">
      <div className="section-heading"><div><div className="eyebrow">DISCOVER YOUR COMMUNITY</div><h2>Rooms worth <span className="gradient-text">joining.</span></h2></div><button className="text-link" onClick={()=>setCategory('All')}>View all <ChevronRight size={16}/></button></div>
      <div className="category-tabs">{categories.map(c=><button key={c} className={category===c?'selected':''} onClick={()=>setCategory(c)}>{c==='Music'?'♫ ':c==='Gaming'?'⌘ ':''}{c}</button>)}</div>
      {rooms.length ? <div className="room-grid">{rooms.map((r:any,i:number)=><RoomCard key={r.id} room={r} index={i} onJoin={()=>onJoin(r.id)}/>)}</div> : <div className="empty-state"><Radio size={30}/><h3>No rooms found</h3><p>Try another category or create a new room.</p></div>}
    </section>
    <section className="section lower-grid">
      <div className="panel feature-panel"><div className="panel-icon purple"><Gamepad2/></div><div><div className="eyebrow">TAKE A BREAK</div><h3>Ready, set, play.</h3><p>Challenge friends and climb the leaderboard in the Game Center.</p><Link to="/games" className="text-link">Explore games <ArrowUpRight size={15}/></Link></div><div className="feature-emoji">🎮</div></div>
      <div className="panel feature-panel gold-panel"><div className="panel-icon gold-bg"><Gift/></div><div><div className="eyebrow">MAKE SOMEONE'S DAY</div><h3>Send a little sparkle.</h3><p>Share a virtual gift and make someone's room unforgettable.</p><Link to="/gifts" className="text-link">Browse gifts <ArrowUpRight size={15}/></Link></div><div className="feature-emoji">🎁</div></div>
    </section>
  </div>
}
function RoomCard({room,index,onJoin}:any){
  const themes=['room-art-one','room-art-two','room-art-three','room-art-four']
  return <article className="room-card">
    <div className={`room-art ${themes[index%4]}`}><span className="room-category">{room.category}</span><span className="live-pill"><i/> LIVE</span><div className="room-art-symbol">{['♫','✦','⌘','☾'][index%4]}</div><div className="room-art-bottom"><span className="avatar-mini">A</span><span className="avatar-mini">M</span><span className="avatar-mini">R</span><small>+{Math.max(0,(room.participant_count||0)-3)} listening</small></div></div>
    <div className="room-card-body"><div className="room-title-line"><h3>{room.name}</h3><span className="room-lock">{room.is_private?<LockKeyhole size={13}/>:null}</span></div><p>{room.description||'Come in, connect and enjoy the vibe.'}</p><div className="room-meta"><span><Users size={14}/>{room.participant_count||0}</span><span><Mic2 size={14}/>{room.seat_count} seats</span><span className="room-id">ID: {room.room_code}</span></div><button className="btn btn-room" onClick={onJoin}>Join room <ChevronRight size={15}/></button></div>
  </article>
}

function CreateRoomModal({onClose,onCreate}:any){
  const [name,setName]=useState('');const [category,setCategory]=useState('Chat');const [seats,setSeats]=useState('16');const [privateRoom,setPrivateRoom]=useState(false);const [description,setDescription]=useState('')
  return <div className="modal-backdrop" onMouseDown={e=>e.target===e.currentTarget&&onClose()}><div className="modal"><div className="modal-head"><div><div className="eyebrow">BUILD YOUR SPACE</div><h2>Create a room</h2></div><button className="icon-btn" onClick={onClose}><X/></button></div>
    <label>Room name<input value={name} onChange={e=>setName(e.target.value)} maxLength={48} placeholder="Give your room a name"/></label>
    <label>Description<textarea value={description} onChange={e=>setDescription(e.target.value)} maxLength={160} placeholder="What is this room about?"/></label>
    <div className="form-row"><label>Category<select value={category} onChange={e=>setCategory(e.target.value)}>{categories.filter(c=>c!=='All').map(c=><option key={c}>{c}</option>)}</select></label><label>Mic seats<select value={seats} onChange={e=>setSeats(e.target.value)}><option value="12">12 seats</option><option value="16">16 seats</option></select></label></div>
    <label className="check-label"><input type="checkbox" checked={privateRoom} onChange={e=>setPrivateRoom(e.target.checked)}/> Private room (invite-only)</label>
    <button className="btn btn-gold full" disabled={!name.trim()} onClick={()=>onCreate({name:name.trim(),description,category,seat_count:Number(seats),is_private:privateRoom})}><Plus size={17}/> Create room</button>
    <small className="muted">A unique Room ID will be generated automatically.</small>
  </div></div>
}

function AuthPage({onDone}:any){
  const [mode,setMode]=useState<'login'|'signup'>('login');const [email,setEmail]=useState('');const [password,setPassword]=useState('');const [username,setUsername]=useState('');const [busy,setBusy]=useState(false);const [error,setError]=useState('')
  async function submit(e:any){e.preventDefault();setBusy(true);setError('');try{
    if(!isSupabaseConfigured) throw new Error('Connect Supabase first: copy .env.example to .env and add your project URL and anon key.')
    if(mode==='signup'){const {error}=await supabase.auth.signUp({email,password,options:{data:{username}}});if(error)throw error;setError('Check your email to confirm your account, then sign in.')}
    else {const {error}=await supabase.auth.signInWithPassword({email,password});if(error)throw error;onDone()}
  }catch(e:any){setError(e.message)}finally{setBusy(false)}}
  async function reset(){if(!email){setError('Enter your email first.');return}const {error}=await supabase.auth.resetPasswordForEmail(email,{redirectTo:location.origin+'/auth'});setError(error?.message||'Password reset email sent if the account exists.')}
  return <div className="auth-wrap"><div className="auth-art"><div className="auth-emblem">A<span>W</span></div><h2>Find your people.<br/><span className="gradient-text">Find your world.</span></h2><p>One place for conversations, games and unforgettable connections.</p></div><form className="auth-card" onSubmit={submit}><div className="eyebrow">WELCOME TO THE COMMUNITY</div><h1>{mode==='login'?'Welcome back':'Create your account'}</h1><p>{mode==='login'?'Sign in to continue your journey.':'Your next chapter starts here.'}</p>{mode==='signup'&&<label>Username<input required value={username} onChange={e=>setUsername(e.target.value)} minLength={3} maxLength={24} placeholder="Choose a username"/></label>}<label>Email address<input type="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com"/></label><label>Password<input type="password" required minLength={6} value={password} onChange={e=>setPassword(e.target.value)} placeholder="At least 6 characters"/></label>{mode==='login'&&<button type="button" className="forgot" onClick={reset}>Forgot password?</button>}{error&&<div className="inline-alert">{error}</div>}<button className="btn btn-gold full" disabled={busy}>{busy?'Please wait…':mode==='login'?'Sign in':'Create account'} <ChevronRight size={16}/></button><div className="auth-switch">{mode==='login'?"New to AKASH WORLD?":"Already have an account?"} <button type="button" onClick={()=>{setMode(mode==='login'?'signup':'login');setError('')}}>{mode==='login'?'Create account':'Sign in'}</button></div><Link to="/" className="guest-link">Continue exploring as guest</Link></form></div>
}

function RoomPage({user,profile,rooms,onNotice}:any){
  const {id=''}=useParams();const room=rooms.find((r:Room)=>r.id===id)||demoRooms.find(r=>r.id===id)
  const [lk,setLk]=useState<any>(null);const [connecting,setConnecting]=useState(false);const [mic,setMic]=useState(false);const [chat,setChat]=useState<any[]>([]);const [message,setMessage]=useState('');const [tab,setTab]=useState('chat');const [joined,setJoined]=useState(false)
  useEffect(()=>{if(!room||!user||!isSupabaseConfigured)return;joinRoom(room.id,user.id).then(()=>setJoined(true)).catch(()=>{});return()=>{if(joined)leaveRoom(room.id,user.id).catch(()=>{})}},[room?.id,user?.id])
  async function connectVoice(){if(!user){onNotice('Sign in to connect to voice.');return}setConnecting(true);try{const token=await fetchLiveKitToken(`room-${room.id}`,profile?.username||user.id);setLk(token)}catch(e:any){onNotice(e.message||'Could not connect to voice')}finally{setConnecting(false)}}
  async function sendMessage(e:any){e.preventDefault();if(!message.trim()||!user)return;const body=message.trim();const {error}=await supabase.from('messages').insert({room_id:room?.id,sender_id:user.id,body,kind:'text'});if(error)onNotice(error.message);else setMessage('')}
  useEffect(()=>{if(!room||!isSupabaseConfigured)return;const ch=supabase.channel(`room-chat-${room.id}`).on('postgres_changes',{event:'INSERT',schema:'public',table:'messages',filter:`room_id=eq.${room.id}`},payload=>setChat(old=>[...old,payload.new])).subscribe();supabase.from('messages').select('id,body,sender_id,created_at').eq('room_id',room.id).order('created_at').limit(50).then(({data})=>setChat(data||[]));return()=>{supabase.removeChannel(ch)}},[room?.id])
  if(!room)return <div className="empty-state"><h2>Room not found</h2><Link to="/">Back to discover</Link></div>
  return <div className="page room-page"><div className="backline"><Link to="/">← Back to rooms</Link><span className="live-pill"><i/> LIVE ROOM</span></div><div className="room-header"><div><div className="eyebrow">{room.category.toUpperCase()} · ROOM ID {room.room_code}</div><h1>{room.name}</h1><p>{room.description||'A place to talk, listen and connect.'}</p></div><button className="btn btn-glass" onClick={()=>{navigator.clipboard?.writeText(location.href);onNotice('Room link copied')}}>Share room <ArrowUpRight size={16}/></button></div>
    {lk?<LiveKitRoom serverUrl={lk.url} token={lk.token} connect audio video={false} onDisconnected={()=>setLk(null)}><RoomAudioRenderer/><VoiceStage onMic={setMic}/></LiveKitRoom>:<div className="voice-stage"><div className="voice-stage-top"><span><Radio size={15}/> VOICE STAGE</span><span>{room.seat_count} MIC SEATS</span></div><div className="seat-grid">{Array.from({length:room.seat_count},(_,i)=><div className={`seat ${i===0?'host-seat':''}`} key={i}><div className="seat-avatar">{i===0?'A':i<4?['M','R','S'][i-1]:'+'}</div><small>{i===0?'Host':i<4?['Mehak','Rayan','Sara'][i-1]:'Open seat'}</small>{i===0&&<Crown size={12}/>}</div>)}</div><div className="voice-connect"><p>Join the conversation with live voice.</p><button className="btn btn-gold" onClick={connectVoice} disabled={connecting}><Mic2 size={16}/>{connecting?'Connecting…':'Connect to voice'}</button></div></div>}
    <div className="room-controls"><button className={`control-btn ${mic?'control-active':''}`} onClick={()=>setMic(!mic)}><Mic2/>{mic?'Mic on':'Mic off'}</button><button className="control-btn" onClick={()=>onNotice('Hand raised')}><ArrowUpRight/>Raise hand</button><button className="control-btn" onClick={()=>onNotice('Gift gallery is ready')}><Gift/>Send gift</button><button className="control-btn danger" onClick={()=>{setLk(null);location.href='/'}}><LogOut/>Leave room</button></div>
    <div className="room-lower"><div className="panel room-chat"><div className="panel-tabs"><button className={tab==='chat'?'active':''} onClick={()=>setTab('chat')}>Room chat</button><button className={tab==='people'?'active':''} onClick={()=>setTab('people')}>People</button></div>{tab==='chat'?<><div className="chat-feed">{chat.map((m:any)=><div className="chat-line" key={m.id}><span className="avatar tiny">{String(m.sender_id).slice(0,1).toUpperCase()}</span><div><b>{String(m.sender_id).slice(0,8)}</b><p>{m.body}</p></div></div>)}{!chat.length&&<p className="muted">Say hello and start the conversation.</p>}</div><form className="chat-compose" onSubmit={sendMessage}><input value={message} onChange={e=>setMessage(e.target.value)} placeholder={user?'Write a message…':'Sign in to chat'} disabled={!user}/><button className="btn btn-gold" disabled={!user||!message.trim()}><ArrowUpRight size={16}/></button></form></>:<div className="people-list"><p>Participants are shown here when connected to the room.</p><span>Host · Room owner</span></div>}</div><div className="panel room-info"><div className="eyebrow">ROOM DETAILS</div><h3>Good vibes only.</h3><p>Be respectful, include everyone and help keep this a welcoming space.</p><div className="room-rule"><Shield size={16}/> Community guidelines apply</div><div className="room-rule"><Users size={16}/> {room.participant_count||1} participants</div><div className="room-rule"><Mic2 size={16}/> {room.seat_count} microphone seats</div></div></div>
  </div>
}
function VoiceStage({onMic}:any){const tracks=useTracks([Track.Source.Microphone],{onlySubscribed:false});return <div className="voice-stage"><div className="voice-stage-top"><span>LIVE VOICE CONNECTION</span><span>{tracks.length} audio tracks</span></div><GridLayout tracks={tracks}><ParticipantTile/></GridLayout><button className="btn btn-glass" onClick={()=>onMic(true)}>Microphone connected</button></div>}

function GamesPage(){return <div className="page"><PageTitle eyebrow="PLAY TOGETHER" title="Game Center" subtitle="Quick matches, friendly competition and unforgettable wins."/><div className="game-grid">{[
  ['Ludo','🎲','Roll the dice and race your tokens.','Multiplayer','ludo'],['Tic Tac Toe','✕','A quick classic for two players.','Playable now','ttt'],['Carrom','⚪','Precision, strategy and friendly matches.','Game room','carrom'],['Snake','🐍','Chase your high score.','Playable now','snake'],['Quiz Arena','🧠','Test your knowledge with friends.','Multiplayer','quiz'],['Spin Wheel','🎡','Give the wheel a spin.','Solo / room','spin']
].map(([name,emoji,desc,type,key])=><GameCard key={key} name={name} emoji={emoji} desc={desc} type={type} game={key}/>)}</div><p className="muted game-note">Tic Tac Toe is playable locally in this starter. Other games have lobby-ready entry points; add authoritative multiplayer game services before public launch.</p></div>}
function GameCard({name,emoji,desc,type,game}:any){const [open,setOpen]=useState(false);return <div className="game-card"><div className="game-emoji">{emoji}</div><span className="game-type">{type}</span><h3>{name}</h3><p>{desc}</p><button className="btn btn-glass full" onClick={()=>setOpen(true)}>Play now <ChevronRight size={15}/></button>{open&&<GameModal name={name} game={game} onClose={()=>setOpen(false)}/>}</div>}
function GameModal({name,game,onClose}:any){return <div className="modal-backdrop"><div className="modal"><div className="modal-head"><h2>{name}</h2><button className="icon-btn" onClick={onClose}><X/></button></div>{game==='ttt'?<TicTacToe/>:<div className="empty-state"><div className="game-emoji">🎮</div><h3>{name} lobby</h3><p>This game needs its game-specific multiplayer service to be configured. Lobby interface is ready for integration.</p></div>}</div></div>}
function TicTacToe(){const [board,setBoard]=useState<Mark[]>(Array(9).fill(null));const [turn,setTurn]=useState<Mark>('X');const winner=getWinner(board);return <div className="ttt"><p>{winner?winner==='draw'?'It is a draw!':`${winner} wins!`:`${turn}'s turn`}</p><div className="ttt-grid">{board.map((m,i)=><button key={i} onClick={()=>{if(!m&&!winner){const next=[...board];next[i]=turn;setBoard(next);setTurn(turn==='X'?'O':'X')}}}>{m}</button>)}</div><button className="btn btn-gold full" onClick={()=>{setBoard(Array(9).fill(null));setTurn('X')}}>New game</button></div>}

function GiftsPage({user,onNotice}:any){const gifts=[['Rose','🌹',25],['Tulips','🌷',80],['Sparkle','✨',120],['Crown','👑',500],['Royal Carriage','🏰',1200],['Galaxy','🌌',2500],['Diamond Heart','💎',5000],['Golden Star','🌟',8000]];return <div className="page"><PageTitle eyebrow="SPREAD THE LOVE" title="Gift Gallery" subtitle="A small gesture can make a big moment."/><div className="gift-grid">{gifts.map(([name,emoji,cost]:any)=><div className="gift-card" key={name}><div>{emoji}</div><h3>{name}</h3><span>◆ {money(cost)}</span><button className="btn btn-gold full" onClick={()=>onNotice(user?'Gift sending requires a recipient and wallet transaction setup.':'Sign in to send gifts.')}>Send gift</button></div>)}</div></div>}
function LeaderboardPage(){return <div className="page"><PageTitle eyebrow="COMMUNITY SPOTLIGHT" title="Leaderboard" subtitle="Celebrate the people bringing the energy."/><div className="panel leaderboard"><div className="leader-row leader-head"><span>RANK</span><span>MEMBER</span><span>LEVEL</span><span>XP</span></div>{['Mehak','Rayan','Areesha','Zain','Sara','Ayan','Mimi'].map((n,i)=><div className="leader-row" key={n}><b className="rank">{String(i+1).padStart(2,'0')}</b><div className="leader-person"><span className="avatar">{n[0]}</span><b>{n}</b>{i===0&&<Crown size={14} className="gold"/>}</div><span>LVL {32-i*3}</span><b>{money(25800-i*3100)}</b></div>)}</div></div>}
function ProfilePage({profile,user,displayName}:any){return <div className="page"><PageTitle eyebrow="YOUR IDENTITY" title="My Profile" subtitle="Make your presence memorable."/><div className="profile-hero panel"><div className="profile-avatar">{displayName.slice(0,1).toUpperCase()}</div><div><h2>{displayName} {profile?.vip_tier!=='none'&&<Crown className="gold" size={17}/>}</h2><p>{profile?.username?`@${profile.username}`:'Guest profile'} · ID {user?.id?.slice(0,8)||'GUEST'}</p><span className="level-pill">LEVEL {profile?.level||1} · {profile?.xp||0} XP</span></div><button className="btn btn-glass" onClick={()=>alert('Profile editing: connect the profile form to your Supabase profile row.')}>Edit profile</button></div><div className="stats-grid"><Stat label="Coins" value={money(profile?.coins||2500)} icon={<Wallet/>}/><Stat label="Diamonds" value={money(profile?.diamonds||0)} icon={<Sparkles/>}/><Stat label="Friends" value="0" icon={<Users/>}/><Stat label="Achievements" value="0" icon={<Trophy/>}/></div></div>}
function Stat({label,value,icon}:any){return <div className="panel stat-card"><span>{icon}</span><b>{value}</b><small>{label}</small></div>}
function WalletPage({profile}:any){return <div className="page"><PageTitle eyebrow="YOUR TREASURE" title="My Wallet" subtitle="Manage your virtual coins and diamonds."/><div className="wallet-grid"><div className="wallet-card"><span>◆</span><small>COIN BALANCE</small><h2>{money(profile?.coins||2500)}</h2><p>Use coins for gifts and room experiences.</p></div><div className="wallet-card diamond"><span>✧</span><small>DIAMOND BALANCE</small><h2>{money(profile?.diamonds||0)}</h2><p>Premium currency and exclusive rewards.</p></div></div><div className="panel notice-panel"><Shield size={18}/><p>Purchases and cash-equivalent transactions are disabled in this starter. Add verified payment provider webhooks and server-side ledger controls before enabling transactions.</p></div></div>}
function VipPage(){return <div className="page"><PageTitle eyebrow="A LITTLE EXTRA MAGIC" title="VIP Membership" subtitle="Make your profile and room presence shine."/><div className="vip-grid">{[['Silver','🌙','Profile frame · VIP badge','Free'],['Gold','👑','Gold frame · Animated entrance · Priority support','Coming soon'],['Royal','💎','Royal effects · Exclusive gifts · Premium perks','Coming soon']].map(([n,e,d,p])=><div className="vip-tier" key={n}><div>{e}</div><h2>{n}</h2><p>{d}</p><button className="btn btn-gold full" onClick={()=>alert('VIP billing is not enabled in this starter.')}>{p}</button></div>)}</div></div>}
function MessagesPage({user}:any){return <div className="page"><PageTitle eyebrow="STAY CONNECTED" title="Messages" subtitle="Your conversations will live here."/><div className="empty-state panel"><MessageCircle size={32}/><h3>Your inbox is waiting</h3><p>Sign in and connect Supabase to start building your conversations.</p>{!user&&<Link to="/auth" className="btn btn-gold">Sign in</Link>}</div></div>}
function SettingsPage(){return <div className="page"><PageTitle eyebrow="MAKE IT YOURS" title="Settings" subtitle="Account and experience preferences."/><div className="panel settings-list">{['Account information','Privacy & safety','Blocked users','Notification preferences','Appearance','Help & support'].map(x=><button key={x} onClick={()=>alert(`${x}: connect this setting to your account preferences.`)}>{x}<ChevronRight/></button>)}</div></div>}
function AdminPage({profile}:any){if(!profile?.is_admin)return <div className="page"><div className="empty-state"><Shield size={34}/><h2>Admin access required</h2><p>This area is restricted to authorized administrators.</p></div></div>;return <div className="page"><PageTitle eyebrow="CONTROL CENTER" title="Admin Dashboard" subtitle="Platform overview and moderation tools."/><div className="stats-grid"><Stat label="Registered users" value="—" icon={<Users/>}/><Stat label="Active rooms" value="—" icon={<Radio/>}/><Stat label="Reports pending" value="—" icon={<Shield/>}/><Stat label="Gift transactions" value="—" icon={<Gift/>}/></div><div className="panel notice-panel">Connect the admin tables and moderation Edge Functions described in README before enabling controls.</div></div>}
function PageTitle({eyebrow,title,subtitle}:any){return <div className="page-title"><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{subtitle}</p></div>}
