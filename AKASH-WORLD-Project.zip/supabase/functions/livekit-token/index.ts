import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { AccessToken } from "https://esm.sh/livekit-server-sdk@2.9.6";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405, headers: cors });
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) return new Response(JSON.stringify({ error: "Authentication required" }), { status: 401, headers: { ...cors, "Content-Type": "application/json" } });

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const auth = await fetch(`${supabaseUrl}/auth/v1/user`, { headers: { Authorization: authHeader, apikey: anonKey } });
    if (!auth.ok) return new Response(JSON.stringify({ error: "Invalid session" }), { status: 401, headers: { ...cors, "Content-Type": "application/json" } });
    const user = await auth.json();

    const { roomName, identity } = await req.json();
    if (typeof roomName !== "string" || !/^room-[0-9a-f-]{8,}$/i.test(roomName)) throw new Error("Invalid room");
    if (typeof identity !== "string" || identity.length > 80) throw new Error("Invalid identity");

    const apiKey = Deno.env.get("LIVEKIT_API_KEY");
    const apiSecret = Deno.env.get("LIVEKIT_API_SECRET");
    const livekitUrl = Deno.env.get("LIVEKIT_URL");
    if (!apiKey || !apiSecret || !livekitUrl) throw new Error("LiveKit server secrets are not configured");

    const token = new AccessToken(apiKey, apiSecret, { identity: user.id, ttl: "1h", metadata: JSON.stringify({ username: identity }) });
    token.addGrant({ roomJoin: true, room: roomName, canPublish: true, canSubscribe: true, canPublishData: true });
    const jwt = await token.toJwt();
    return new Response(JSON.stringify({ token: jwt, url: livekitUrl }), { headers: { ...cors, "Content-Type": "application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Token generation failed" }), { status: 400, headers: { ...cors, "Content-Type": "application/json" } });
  }
});
