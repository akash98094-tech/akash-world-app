-- AKASH WORLD initial schema. Run in Supabase SQL Editor.
create extension if not exists pgcrypto;

create type public.room_category as enum ('Music','Chat','Gaming','Friendship','Entertainment');
create type public.room_status as enum ('live','ended','scheduled');
create type public.room_role as enum ('host','co_host','moderator','speaker','listener');
create type public.message_kind as enum ('text','system','voice');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null check (char_length(username) between 3 and 24),
  display_name text,
  avatar_url text,
  bio text default '',
  level integer not null default 1 check (level >= 1),
  xp bigint not null default 0 check (xp >= 0),
  coins bigint not null default 2500 check (coins >= 0),
  diamonds bigint not null default 0 check (diamonds >= 0),
  vip_tier text not null default 'none' check (vip_tier in ('none','silver','gold','royal')),
  is_admin boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.rooms (
  id uuid primary key default gen_random_uuid(),
  room_code text unique not null,
  name text not null check (char_length(name) between 2 and 48),
  description text,
  category public.room_category not null default 'Chat',
  cover_url text,
  host_id uuid not null references public.profiles(id),
  is_private boolean not null default false,
  password_hash text,
  seat_count integer not null default 16 check (seat_count in (12,16)),
  status public.room_status not null default 'live',
  announcement text,
  created_at timestamptz not null default now(),
  ended_at timestamptz
);
create index rooms_live_created_idx on public.rooms(status, created_at desc);
create index rooms_code_idx on public.rooms(room_code);

create table public.room_participants (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.rooms(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  role public.room_role not null default 'listener',
  seat_number integer,
  is_muted boolean not null default false,
  joined_at timestamptz not null default now(),
  unique(room_id,user_id),
  unique(room_id,seat_number)
);

create table public.messages (
  id uuid primary key default gen_random_uuid(),
  room_id uuid references public.rooms(id) on delete cascade,
  conversation_id uuid,
  sender_id uuid not null references public.profiles(id),
  body text not null check (char_length(body) between 1 and 2000),
  kind public.message_kind not null default 'text',
  created_at timestamptz not null default now()
);
create index messages_room_created_idx on public.messages(room_id,created_at);

create table public.friendships (
  id uuid primary key default gen_random_uuid(),
  requester_id uuid not null references public.profiles(id) on delete cascade,
  addressee_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','accepted','declined','blocked')),
  created_at timestamptz not null default now(),
  unique(requester_id,addressee_id),
  check (requester_id <> addressee_id)
);

create table public.gifts (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  emoji text not null,
  coin_price bigint not null check (coin_price >= 0),
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
insert into public.gifts(name,emoji,coin_price) values
('Rose','🌹',25),('Tulips','🌷',80),('Sparkle','✨',120),('Crown','👑',500),
('Royal Carriage','🏰',1200),('Galaxy','🌌',2500),('Diamond Heart','💎',5000),('Golden Star','🌟',8000)
on conflict do nothing;

create table public.transactions (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid references public.profiles(id),
  recipient_id uuid references public.profiles(id),
  gift_id uuid references public.gifts(id),
  room_id uuid references public.rooms(id),
  currency text not null check (currency in ('coins','diamonds','real')),
  amount bigint not null check (amount > 0),
  status text not null default 'pending' check (status in ('pending','completed','failed','refunded')),
  provider_reference text,
  created_at timestamptz not null default now()
);

create table public.games (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name text not null,
  is_enabled boolean not null default true,
  config jsonb not null default '{}'::jsonb
);
insert into public.games(slug,name) values
('ludo','Ludo'),('tic-tac-toe','Tic Tac Toe'),('carrom','Carrom'),('snake','Snake'),('quiz','Quiz Arena'),('spin-wheel','Spin Wheel')
on conflict (slug) do nothing;

create table public.game_sessions (
  id uuid primary key default gen_random_uuid(),
  game_id uuid not null references public.games(id),
  room_code text unique not null,
  host_id uuid not null references public.profiles(id),
  status text not null default 'waiting' check (status in ('waiting','active','completed','cancelled')),
  state jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  ended_at timestamptz
);
create table public.game_players (
  session_id uuid not null references public.game_sessions(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  score integer not null default 0,
  joined_at timestamptz not null default now(),
  primary key(session_id,user_id)
);

create table public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id),
  target_user_id uuid references public.profiles(id),
  room_id uuid references public.rooms(id),
  reason text not null check (char_length(reason) between 3 and 500),
  status text not null default 'open' check (status in ('open','reviewing','resolved','dismissed')),
  moderator_id uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  resolved_at timestamptz
);
create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  body text not null,
  kind text not null default 'general',
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create table public.vip_subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id),
  tier text not null check (tier in ('silver','gold','royal')),
  status text not null default 'pending' check (status in ('pending','active','cancelled','expired')),
  starts_at timestamptz,
  ends_at timestamptz,
  provider_reference text,
  created_at timestamptz not null default now()
);
create table public.user_blocks (
  blocker_id uuid not null references public.profiles(id) on delete cascade,
  blocked_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(blocker_id,blocked_id),
  check(blocker_id <> blocked_id)
);

-- Create a profile automatically after Supabase Auth signup.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare uname text;
begin
  uname := coalesce(new.raw_user_meta_data->>'username', 'member_' || substr(new.id::text,1,8));
  insert into public.profiles(id,username,display_name)
  values(new.id, uname, coalesce(new.raw_user_meta_data->>'display_name',uname))
  on conflict (id) do nothing;
  return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.profiles where id=auth.uid() and is_admin=true);
$$;

-- RLS
alter table public.profiles enable row level security;
alter table public.rooms enable row level security;
alter table public.room_participants enable row level security;
alter table public.messages enable row level security;
alter table public.friendships enable row level security;
alter table public.gifts enable row level security;
alter table public.transactions enable row level security;
alter table public.games enable row level security;
alter table public.game_sessions enable row level security;
alter table public.game_players enable row level security;
alter table public.reports enable row level security;
alter table public.notifications enable row level security;
alter table public.vip_subscriptions enable row level security;
alter table public.user_blocks enable row level security;

create policy "Profiles are viewable by authenticated users" on public.profiles for select to authenticated using (true);
create policy "Users update own profile" on public.profiles for update to authenticated using (id=auth.uid()) with check (id=auth.uid() and is_admin=public.is_admin());
create policy "Rooms visible when public or participant" on public.rooms for select to anon,authenticated using (not is_private or host_id=auth.uid() or exists(select 1 from public.room_participants rp where rp.room_id=id and rp.user_id=auth.uid()));
create policy "Authenticated users create rooms" on public.rooms for insert to authenticated with check (host_id=auth.uid());
create policy "Host or admin updates room" on public.rooms for update to authenticated using (host_id=auth.uid() or public.is_admin()) with check (host_id=auth.uid() or public.is_admin());
create policy "Host or admin deletes room" on public.rooms for delete to authenticated using (host_id=auth.uid() or public.is_admin());
create policy "Participants visible to authenticated" on public.room_participants for select to authenticated using (true);
create policy "Users join themselves" on public.room_participants for insert to authenticated with check (user_id=auth.uid());
create policy "Users leave themselves" on public.room_participants for delete to authenticated using (user_id=auth.uid() or public.is_admin());
create policy "Messages visible to room participants" on public.messages for select to authenticated using (room_id is null or exists(select 1 from public.room_participants rp where rp.room_id=messages.room_id and rp.user_id=auth.uid()));
create policy "Participants send room messages" on public.messages for insert to authenticated with check (sender_id=auth.uid() and (room_id is null or exists(select 1 from public.room_participants rp where rp.room_id=messages.room_id and rp.user_id=auth.uid())));
create policy "Friendship participants can read" on public.friendships for select to authenticated using (requester_id=auth.uid() or addressee_id=auth.uid());
create policy "Users send friendship requests" on public.friendships for insert to authenticated with check (requester_id=auth.uid());
create policy "Friendship participants update" on public.friendships for update to authenticated using (requester_id=auth.uid() or addressee_id=auth.uid());
create policy "Active gifts are public" on public.gifts for select to anon,authenticated using (is_active or public.is_admin());
create policy "Admin manages gifts" on public.gifts for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "Users see own transactions" on public.transactions for select to authenticated using (sender_id=auth.uid() or recipient_id=auth.uid() or public.is_admin());
create policy "Games are public" on public.games for select to anon,authenticated using (is_enabled or public.is_admin());
create policy "Admin manages games" on public.games for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "Game sessions visible" on public.game_sessions for select to authenticated using (true);
create policy "Host creates game sessions" on public.game_sessions for insert to authenticated with check (host_id=auth.uid());
create policy "Host/admin updates sessions" on public.game_sessions for update to authenticated using (host_id=auth.uid() or public.is_admin()) with check (host_id=auth.uid() or public.is_admin());
create policy "Players visible" on public.game_players for select to authenticated using (true);
create policy "Players join self" on public.game_players for insert to authenticated with check (user_id=auth.uid());
create policy "Players leave self" on public.game_players for delete to authenticated using (user_id=auth.uid());
create policy "Users create reports" on public.reports for insert to authenticated with check (reporter_id=auth.uid());
create policy "Reporter and admin view reports" on public.reports for select to authenticated using (reporter_id=auth.uid() or public.is_admin());
create policy "Admins moderate reports" on public.reports for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "Users view own notifications" on public.notifications for select to authenticated using (user_id=auth.uid());
create policy "Users update own notifications" on public.notifications for update to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy "Users view own VIP" on public.vip_subscriptions for select to authenticated using (user_id=auth.uid() or public.is_admin());
create policy "Users view own blocks" on public.user_blocks for select to authenticated using (blocker_id=auth.uid());
create policy "Users block others" on public.user_blocks for insert to authenticated with check (blocker_id=auth.uid());
create policy "Users unblock others" on public.user_blocks for delete to authenticated using (blocker_id=auth.uid());

-- Realtime publication (ignore if already added manually)
do $$ begin
  alter publication supabase_realtime add table public.rooms;
exception when duplicate_object then null;
when undefined_object then null;
end $$;
do $$ begin
  alter publication supabase_realtime add table public.room_participants;
exception when duplicate_object then null;
when undefined_object then null;
end $$;
do $$ begin
  alter publication supabase_realtime add table public.messages;
exception when duplicate_object then null;
when undefined_object then null;
end $$;
